# V1beta1ExplainersConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aix** | [**V1beta1ExplainerConfig**](V1beta1ExplainerConfig.md) |  | [optional] 
**alibi** | [**V1beta1ExplainerConfig**](V1beta1ExplainerConfig.md) |  | [optional] 
**art** | [**V1beta1ExplainerConfig**](V1beta1ExplainerConfig.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


