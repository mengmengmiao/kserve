# V1beta1IngressConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**disable_istio_virtual_host** | **bool** |  | [optional] 
**domain_template** | **str** |  | [optional] 
**ingress_class_name** | **str** |  | [optional] 
**ingress_domain** | **str** |  | [optional] 
**ingress_gateway** | **str** |  | [optional] 
**ingress_service** | **str** |  | [optional] 
**local_gateway** | **str** |  | [optional] 
**local_gateway_service** | **str** |  | [optional] 
**url_scheme** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


