# V1beta1DeployConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**default_deployment_mode** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


