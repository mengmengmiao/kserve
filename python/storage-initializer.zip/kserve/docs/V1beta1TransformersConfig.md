# V1beta1TransformersConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**feast** | [**V1beta1TransformerConfig**](V1beta1TransformerConfig.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


