# V1beta1PredictorProtocols

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**v1** | [**V1beta1PredictorConfig**](V1beta1PredictorConfig.md) |  | [optional] 
**v2** | [**V1beta1PredictorConfig**](V1beta1PredictorConfig.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


