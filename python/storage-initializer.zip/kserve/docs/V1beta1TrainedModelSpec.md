# V1beta1TrainedModelSpec

TrainedModelSpec defines the trained model spec
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**inference_service** | **str** | parent inference service to deploy to | 
**model** | [**V1beta1ModelSpec**](V1beta1ModelSpec.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


