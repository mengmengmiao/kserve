# V1beta1ExplainerConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**default_image_version** | **str** | default explainer docker image version | [default to '']
**image** | **str** | explainer docker image name | [default to '']

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


