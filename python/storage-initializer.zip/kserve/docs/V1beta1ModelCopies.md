# V1beta1ModelCopies

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**failed_copies** | **int** | How many copies of this predictor&#39;s models failed to load recently | [default to 0]
**total_copies** | **int** | Total number copies of this predictor&#39;s models that are currently loaded | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


