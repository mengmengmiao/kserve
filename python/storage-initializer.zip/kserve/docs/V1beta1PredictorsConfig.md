# V1beta1PredictorsConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lightgbm** | [**V1beta1PredictorConfig**](V1beta1PredictorConfig.md) |  | [optional] 
**onnx** | [**V1beta1PredictorConfig**](V1beta1PredictorConfig.md) |  | [optional] 
**paddle** | [**V1beta1PredictorConfig**](V1beta1PredictorConfig.md) |  | [optional] 
**pmml** | [**V1beta1PredictorConfig**](V1beta1PredictorConfig.md) |  | [optional] 
**pytorch** | [**V1beta1PredictorConfig**](V1beta1PredictorConfig.md) |  | [optional] 
**sklearn** | [**V1beta1PredictorProtocols**](V1beta1PredictorProtocols.md) |  | [optional] 
**tensorflow** | [**V1beta1PredictorConfig**](V1beta1PredictorConfig.md) |  | [optional] 
**triton** | [**V1beta1PredictorConfig**](V1beta1PredictorConfig.md) |  | [optional] 
**xgboost** | [**V1beta1PredictorProtocols**](V1beta1PredictorProtocols.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


