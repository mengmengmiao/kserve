# V1beta1ModelRevisionStates

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**active_model_state** | **str** | High level state string: Pending, Standby, Loading, Loaded, FailedToLoad | [default to '']
**target_model_state** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


