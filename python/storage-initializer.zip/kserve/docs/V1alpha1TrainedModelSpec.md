# V1alpha1TrainedModelSpec

TrainedModelSpec defines the TrainedModel spec
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**inference_service** | **str** | parent inference service to deploy to | [default to '']
**model** | [**V1alpha1ModelSpec**](V1alpha1ModelSpec.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


